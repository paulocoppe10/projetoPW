<?php
include("conexao.php");

if($_POST){
	newUser($_POST['nome'],$_POST['email'],$_POST['senha']);
}
if(isset($_GET['ativar'])){
	validar($_GET[ativar1]);
}
else{
	?>
	<meta charset="utf-8">
	<form>
		digite o codigo de validação
		<input type="text" name="ativar">
		<button>validar</button>
	</form>
	<?php
}
//profrodolfo.com.br/gf/gf.txt