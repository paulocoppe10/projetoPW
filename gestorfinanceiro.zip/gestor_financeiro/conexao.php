<?php
$a = 'localhost';
$b = 'root';
$c = 'usbw';
$d = 'gestor';
$conn = new mysqli($a,$b,$c,$d);
if(!$conn){
	alert("Erro ao conectar!")
}

function newUser($nome,$email,$senha){
	$validacao = md5($nome.date('d'));
	$sql = 'INSERT INTO tb_usuario VALUES(null,"'.$nome.'";"'.$email.'";"'.$senha.'";"img/semfoto.png","'.$validacao.'")';
	$resultado = $GLOBALS['con']-query($sql);
	if($resultado){
		//vamos enviar o email
		$msg = 'Para finalizar o seu cadastro ative a sua conta: '
		$msg.= $validacao;
		if(mail($email,"GESTOR-FINANCEIRO[ativar conta]",$msg)){
		    alert("para ativar a sua conta acesse seu email e resgate o codigo!");
		}else{
			alert("falha ao enviar codigo de ativação");
		}
	}else{
		alert("erro ao cadastrar, tente novamente!");
	}
}
function alert($msg){
	echo '<script>alert("'.$msg.'");</script>';
}
